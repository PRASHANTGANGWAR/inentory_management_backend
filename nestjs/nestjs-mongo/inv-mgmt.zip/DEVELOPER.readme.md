
```
Api's created
```
Manage User
1. List all the users on dashboard.
2. Add new user.
3. Activate/deactivate User.
4. Reset user password.

Manage Inventory
1. List all the inventory.
2. inwarding or insert of inventory data.
 It includes the image insertions as well.
4. list all the client. may be required!!!
5. INventory outwarding : update the sealId with the withdrawn OLGC also update the sealId with new number.
If all the OLGC are withdrawn mark seal as empty.


Manage Client
1. Client ID, crate a new table for client Id and add delete mechanism in this table.

