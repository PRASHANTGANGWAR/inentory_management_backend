import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { CreateInventoryDto } from './dto/create-inventory.dto';
import { UpdateInventoryDto, UpdateStatusDto, UpdatePasswordDto, passwordDto } from './dto/update-inventory.dto';

import { Inventory } from './schemas/inventory.schema';
import { InventoryService } from './inventory.service';
import { INestApplication } from '@nestjs/common';


@Controller('inventory')
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}

  @Get(':inventoryId')
  async getInventory(@Param('inventoryId') inventoryId: string): Promise<Inventory> {
      console.log("------------here", inventoryId)
    return this.inventoryService.getInventoryById(inventoryId);
  }

  @Get()
  async getUsers(): Promise<Inventory[]> {
    return this.inventoryService.getInventory();
  }

  @Post()
  async createUser(@Body() createInventoryDto: CreateInventoryDto): Promise<Inventory> {
    return this.inventoryService.createInventory(createInventoryDto.originalSealId, createInventoryDto.currentSealId, createInventoryDto.coinCount, createInventoryDto.tokenCount, createInventoryDto.sealStatus, createInventoryDto.currentCoinCount, createInventoryDto.currentTokenCount, createInventoryDto.previousSealId, createInventoryDto.previousCoinCount )
  }

  @Patch(':inventoryId')
  async updateUser(@Param('inventoryId') inventoryId: string, @Body() UpdateInventoryDto: UpdateInventoryDto): Promise<Inventory> {
      console.log("=========here inventorys", inventoryId, UpdateInventoryDto)
      return this.inventoryService.updateInventory(inventoryId, UpdateInventoryDto);
  }

  // @Patch('/update-status/:userId')
  // async updateUserStatus(@Param('userId') userId: string, @Body() UpdatePasswordDto: UpdatePasswordDto): Promise<User> {
  //     return this.usersService.updateUserStatus(userId, UpdatePasswordDto);
  // }

//   @Patch('/update-password/:userId')
//   async updateUserPassword(@Param('userId') userId: string, @Body() passwordDto: passwordDto): Promise<object> {
//       console.log(passwordDto, "passwordDto");
//       const user = await this.inventoryService.getUserById(userId);
//       console.log("user", user.password);
//       if(passwordDto.oldPassword == user.password){
//         this.inventoryService.updatePassword(userId, {password: passwordDto.newPassword});
//         return { message: "updated", success: true};
//       } else {
//         return { message: "Old assword mismatch", success: false};
//       }
//   }
}
