export const MONGO_CONNECTION= 'mongodb://localhost/demo';
export const PORT= 3000;
export const DEFAULT_MESSAGE= 'Inventory-management application running successfully'
